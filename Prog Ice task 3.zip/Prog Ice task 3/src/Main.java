// Abstract class representing a generic product
abstract class Product {
    // Fields shared by all products
    protected String name;
    protected double price;

    // Constructor to initialize common fields
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Abstract method - each subclass must provide its own discount logic
    public abstract double getDiscountedPrice();

    // Helper method to display product info
    public void displayInfo() {
        System.out.printf("%-15s Original: $%-8.2f Discounted: $%.2f%n",
                name, price, getDiscountedPrice());
    }
}

// Clothing subclass - applies a 10% discount
class Clothing extends Product {

    public Clothing(String name, double price) {
        super(name, price);
    }

    @Override
    public double getDiscountedPrice() {
        return price - (price * 0.10); // 10% off
    }
}

// Electronics subclass - applies a 5% discount
class Electronics extends Product {

    public Electronics(String name, double price) {
        super(name, price);
    }

    @Override
    public double getDiscountedPrice() {
        return price - (price * 0.05); // 5% off
    }
}

public class ProductTask {
    public static void main(String[] args) {

        // Create an array of Product references holding different subclass objects
        Product[] products = {
            new Clothing("T-Shirt", 25.00),
            new Electronics("Headphones", 120.00),
            new Clothing("Jeans", 60.00),
            new Electronics("Smartphone", 800.00),
            new Clothing("Jacket", 150.00)
        };

        System.out.println("=== Product Discount Report ===\n");

        // Loop through the array and print each product's discounted price
        for (Product p : products) {
            p.displayInfo(); // Polymorphism: calls the correct getDiscountedPrice()
        }
    }
}